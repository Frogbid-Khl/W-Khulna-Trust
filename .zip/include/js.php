
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/form-validator.min.js"></script>

<script src="assets/js/contact-form-script.js"></script>

<script src="assets/js/jquery.ajaxchimp.min.js"></script>

<script src="assets/js/jquery.meanmenu.js"></script>

<script src="assets/js/jquery-modal-video.min.js"></script>


<script src="assets/js/wow.min.js"></script>
<script src="assets/js/lightbox.min.js"></script>

<script src="assets/js/owl.carousel.min.js"></script>

<script src="assets/js/odometer.min.js"></script>
<script src="assets/js/jquery.appear.min.js"></script>

<script src="assets/js/jquery.nice-select.min.js"></script>

<script src="assets/js/custom.js"></script>